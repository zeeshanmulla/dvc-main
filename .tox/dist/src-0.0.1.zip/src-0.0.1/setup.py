from setuptools import setup, find_packages

setup(
    name="src",
    version="0.0.1",
    descriptio="its a wine Q package",
    author= "z",
    packages= find_packages(),
    license="MIT"
)